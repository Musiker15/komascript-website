The directories of this package contains some examples from the book:

    Markus Kohm
    KOMA-Script
    Eine Sammlung von Klassen und Paketen für LaTeX2e
    5., überarbeitete und erweiterte Auflage für KOMA-Script 3
    Lehmanns Media, Berlin, Edition dante, 680 Seiten, 2014
    ISBN-13: 978-3-86541-613-1
    <http://www.lob.de/isbn/3865416131>

There are no further describtions of these examples. So without the book they
are useless. 

For legal note see LEGAL.txt.
