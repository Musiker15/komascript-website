The directories of this package contains some examples from the book:

    Markus Kohm, Jens-Uwe Morawski
    KOMA-Script
    Eine Sammlung von Klassen und Paketen für LaTeX2e
    4., überarbeitete und erweiterte Auflage für KOMA-Script 3
    Lehmanns Media, Berlin, Edition dante, 592 Seiten, 2012
    ISBN-13: 978-3-86541-459-5
    <http://www.lob.de/isbn/3865414595>

There are no further describtions of these examples. So without the book they
are useless. 

For legal note see LEGAL.txt.
