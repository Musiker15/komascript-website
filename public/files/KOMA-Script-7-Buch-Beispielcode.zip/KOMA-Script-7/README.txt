The directories of this package contains some examples from the book:

    Markus Kohm
    KOMA-Script
    Eine Sammlung von Klassen und Paketen für LaTeX2e
    7., überarbeitete und erweiterte Auflage für KOMA-Script 3
    Lehmanns Media, Berlin, Edition dante, 728 pages, 2020
    ISBN-13: 978-3-96543-097-6 (Print)
    <https://www.lehmanns.de/title_id/51375541>
    ISBN-13: 978-3-96543-103-4 (eBook)
    <https://www.lehmanns.de/title_id/51374682>

There are no further descriptions of these examples. So without the book they
are useless. 

For legal note see LEGAL.txt.
